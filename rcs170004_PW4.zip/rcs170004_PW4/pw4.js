$(document).ready(function(){

	function loadData(){
		   
		   $.ajax({

				 url: "movies.xml",
				 dataType: "xml",
				 success: function(data) {
				    alert("file is loaded");
				    $(data).find('movie').each(function(){

				    	//var movie=$(this).attr("id");
						var title = $(this).find('title').text();

						var genres = [];
						$(this).find('genre').each(function(){
							genres.push($(this).text());
						});
						genres=genres.join(",");
						//$(this).find('genre').text();
						var director= $(this).find('director').text();
						var cast=[];
						$(this).find('cast').each(function(){
							cast.push($(this).text());
						});
						cast=cast.join(",");
						//$(this).find('cast').text();
						var short_desc=$(this).find('synopsis').text();
						var imdb=$(this).find('score').text();

						var info = $('<tr></tr>').html('<td>' +title+ '</td><td>' +genres+ '</td><td>' +director+ '</td><td>' +cast+ '</td><td>' +short_desc+ '</td><td>' +imdb+ '</td>').appendTo('#movie_data');
				     
				     });
					},
                 error: function() { alert("error loading file");}
				
			});

		}
		loadData();

});
