$(document).ready(function() {
	// your js code goes here...

	$("#username").after("<span id='validateUser'>The username field must contain only alphabetical or numeric characters.</span>");
	$("#password").after("<span id='validatePass'>The password field should be at least six characters long.</span>");
	$("#email").after("<span id='validateEmail'>The email field should be a valid email address (abc@def.xyz). Everything is alphanumeric, except “@”. There can be any number of characters before and after “@” and there will be three characters after dot. </span>");

	$("#validateUser").hide();
	$("#validatePass").hide();
	$("#validateEmail").hide();

	$("#password").focus(
		function()
		{

			$("#validatePass").removeClass().addClass("info").text("The password field should be at least six characters long.").show();	

		}
	).blur(
	    function()
		{

			if($("#password").val().length==0)
				$("#validatePass").hide();
			else if($("#password").val().length<6)
				$("#validatePass").text("Error").addClass("error").show();
			else
				$("#validatePass").text("OK").removeClass().addClass("ok").show();
		}
	);


	$("#email").focus(
		function()
		{

			$("#validateEmail").removeClass().addClass("info").text("The email field should be a valid email address (abc@def.xyz). Everything is alphanumeric, except “@”. There can be any number of characters before and after “@” and there will be three characters after dot.").show();

			

		}
	).blur(
	function()
		{
			var regex= /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{3}$/;
			var email1=$("#email").val();
			if(email1.length==0)
				$("#validateEmail").hide();
			else if(!regex.test(email1))
				$("#validateEmail").addClass("error").text("Error");
		    else
				$("#validateEmail").text("OK").removeClass().addClass("ok").show();
		}
	);

	$("#username").focus(
		function()
		{

			$("#validateUser").removeClass().addClass("info").text("The username field must contain only alphabetical or numeric characters").show();	

		}
	).blur(
	function()
		{

			var regex=new RegExp("^[a-zA-Z0-9]+$");
			var user=$("#username").val();
			if(user.length==0)
				$("#validateUser").hide();
			else if(!regex.test(user))
				$("#validateUser").addClass("error").text("Error").show();
			else
				$("#validateUser").text("OK").removeClass().addClass("ok").show();
		}
	);

});
